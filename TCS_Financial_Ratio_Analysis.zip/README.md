# TCS Financial Statement Ratio Analysis

## Overview
This project analyzes key financial ratios for Tata Consultancy Services (TCS) using real 5-year data (2019–2023). It includes profitability, liquidity, solvency, and operational efficiency metrics using Excel with visualization and dashboarding.

## Contents
- Financials: Revenue, Net Profit, Assets, Equity, etc.
- Ratio Calculations: Current Ratio, ROE, ROA, etc.
- Dashboard: Summary charts and insights (Excel-based)

## Tools Used
- Excel
- Financial data sourced from MoneyControl & TCS annual reports

## Author
Timmaiahgari Shivasai
